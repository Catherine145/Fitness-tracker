// Load saved data from localStorage
let userProfile = JSON.parse(localStorage.getItem('userProfile')) || {};
let workouts = JSON.parse(localStorage.getItem('workouts')) || [];

// Profile Form Submission
document.getElementById('profile-form').addEventListener('submit', function (e) {
  e.preventDefault();
  userProfile = {
    name: document.getElementById('name').value,
    age: document.getElementById('age').value,
    weight: document.getElementById('weight').value,
    height: document.getElementById('height').value,
  };

  // Save profile to localStorage
  localStorage.setItem('userProfile', JSON.stringify(userProfile));

  // Calculate health stats
  const { bmi, idealWeight, dailyCalories } = calculateHealthStats(
    userProfile.weight,
    userProfile.height,
    userProfile.age
  );

  // Display health stats
  alert(`Profile Saved!\nBMI: ${bmi}\nIdeal Weight: ${idealWeight} kg\nDaily Calories: ${dailyCalories}`);
  displayProfile();
});

// Workout Form Submission
document.getElementById('workout-form').addEventListener('submit', function (e) {
  e.preventDefault();
  const workout = {
    exercise: document.getElementById('exercise').value,
    duration: document.getElementById('duration').value,
    calories: document.getElementById('calories').value,
    date: new Date().toLocaleDateString(),
  };

  // Add workout to the list
  workouts.push(workout);
  localStorage.setItem('workouts', JSON.stringify(workouts));

  // Clear form and display workouts
  document.getElementById('workout-form').reset();
  displayWorkouts();
});

// Display Profile
function displayProfile() {
  if (userProfile.name) {
    document.getElementById('name').value = userProfile.name;
    document.getElementById('age').value = userProfile.age;
    document.getElementById('weight').value = userProfile.weight;
    document.getElementById('height').value = userProfile.height;
  }
}

// Display Workouts
function displayWorkouts() {
  const workoutList = document.getElementById('workout-list');
  workoutList.innerHTML = ''; // Clear the list

  workouts.forEach((workout) => {
    const workoutItem = document.createElement('li');
    workoutItem.textContent = `${workout.exercise} - ${workout.duration} minutes, ${workout.calories} calories burned (${workout.date})`;
    workoutList.appendChild(workoutItem);
  });
}

// Calculate BMI, Ideal Weight, and Daily Calories
function calculateHealthStats(weight, height, age) {
  const heightInMeters = height / 100;
  const bmi = (weight / (heightInMeters * heightInMeters)).toFixed(2);
  const idealWeight = (22 * (heightInMeters * heightInMeters)).toFixed(2);
  const bmr = 10 * weight + 6.25 * height - 5 * age + 5; // For men
  const dailyCalories = Math.round(bmr * 1.55); // Moderate activity level
  return { bmi, idealWeight, dailyCalories };
}

// Suggest Exercises
const exercises = ['Running', 'Cycling', 'Swimming', 'Yoga', 'Weightlifting', 'Jump Rope', 'Push-ups', 'Squats'];
document.getElementById('suggest-exercise').addEventListener('click', function () {
  const randomExercise = exercises[Math.floor(Math.random() * exercises.length)];
  alert(`How about trying: ${randomExercise}?`);
});

// Health Problems Recommendations
document.getElementById('health-problems').addEventListener('change', function (e) {
  const recommendations = document.getElementById('health-recommendations');
  recommendations.style.display = e.target.checked ? 'block' : 'none';
});

// Motivational Quotes
const quotes = [
  'The only bad workout is the one you didn’t do!',
  'Don’t stop until you’re proud.',
  'Your body can stand almost anything. It’s your mind you have to convince.',
  'Sweat is fat crying.',
  'Strive for progress, not perfection.',
];

function displayMotivationalQuote() {
  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
  alert(`Motivational Quote: ${randomQuote}`);
}

// Load saved data and display quote when the page loads
window.onload = function () {
  displayMotivationalQuote();
  displayProfile();
  displayWorkouts();
};